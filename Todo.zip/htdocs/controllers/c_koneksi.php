<?php

class Koneksi {
    // Properti kelas
    private $server = "sql303.infinityfree.com";
    private $username = "ifo_38654075";
    private $password = "qHI51FcSwthSbN";
    private $db = "ifo_38654075_ujikom_todolist";
    public $koneksi;

    // Konstruktor kelas
    public function __construct() {
        $this->koneksi = new mysqli($this->server, $this->username, $this->password, $this->db);

        // Mengecek koneksi
        if ($this->koneksi->connect_error) {
            die("Koneksi database gagal: " . $this->koneksi->connect_error);
        } else {
            echo "Koneksi ke database " . $this->db . " berhasil";
        }
    }
}

// Membuat objek koneksi
$koneksi = new Koneksi();

?>
